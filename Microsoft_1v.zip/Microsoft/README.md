Requirements:

$ sudo pip install pandas
$ sudo pip install numpy==1.14.5

$ python main.py #To run the code

